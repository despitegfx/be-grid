import * as i0 from '@angular/core';
import { EventEmitter, Component, Input, Output, Injectable, ViewChild, NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import * as i3 from '@angular/material/table';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import * as i5 from '@angular/material/sort';
import { MatSort, MatSortModule } from '@angular/material/sort';
import * as i6 from '@angular/material/paginator';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import * as i7 from '@angular/cdk/drag-drop';
import { moveItemInArray, DragDropModule } from '@angular/cdk/drag-drop';
import { SelectionModel } from '@angular/cdk/collections';
import { BehaviorSubject } from 'rxjs';
import * as i1 from '@angular/cdk/a11y';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i4 from '@angular/material/checkbox';
import { MatCheckboxModule } from '@angular/material/checkbox';
import * as i8 from 'mat-table-exporter';
import { MatTableExporterModule } from 'mat-table-exporter';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';

class BeButtonComponent {
    constructor() {
        this.btnClick = new EventEmitter();
    }
    actionClick(action) {
        this.btnClick.emit({ row: this.rowData, action: action });
    }
}
BeButtonComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: BeButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
BeButtonComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: BeButtonComponent, selector: "be-button", inputs: { label: "label", type: "type", color: "color", disabledButton: "disabledButton", hideButton: "hideButton", rowData: "rowData" }, outputs: { btnClick: "btnClick" }, ngImport: i0, template: "<button *ngIf=\"type=='fill' && color=='blue'\" class=\"fill-btn-blue fill-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\"\n[disabled]=\"disabledButton\"\n>{{label}}</button>\n\n<button *ngIf=\"type=='fill' && color=='red'\" class=\"fill-btn-red fill-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\" \n[disabled]=\"disabledButton\"\n>{{label}}</button>\n\n<button *ngIf=\"type=='fill' && color=='orange'\" class=\"fill-btn-orange fill-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\" \n[disabled]=\"disabledButton\"\n>{{label}}</button>\n\n<button *ngIf=\"type=='fill' && color=='yellow'\" class=\"fill-btn-yellow fill-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\" \n[disabled]=\"disabledButton\" \n>{{label}}</button>\n\n<button *ngIf=\"type=='fill' && color=='green'\" class=\"fill-btn-green fill-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\" \n[disabled]=\"disabledButton\" \n>{{label}}</button>\n\n<!-- outline -->\n<button *ngIf=\"type=='outline' && color=='blue'\" class=\"outline-btn-blue outline-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\" \n[disabled]=\"disabledButton\"\n>{{label}}</button>\n\n<button *ngIf=\"type=='outline' && color=='red'\" class=\"outline-btn-red outline-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\" \n[disabled]=\"disabledButton\"\n>{{label}}</button>\n\n<button *ngIf=\"type=='outline' && color=='orange'\" class=\"outline-btn-orange outline-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\" \n[disabled]=\"disabledButton\"\n>{{label}}</button>\n\n<button *ngIf=\"type=='outline' && color=='yellow'\" class=\"outline-btn-yellow outline-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\" \n[disabled]=\"disabledButton\"\n>{{label}}</button>\n\n<button *ngIf=\"type=='outline' && color=='green'\" class=\"outline-btn-green outline-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\" \n[disabled]=\"disabledButton\"\n>{{label}}</button>\n\n\n", styles: [".fill-btn-blue{background:#0F4C8A;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#f0f8ff;border-radius:5px;font-size:12px;cursor:pointer;border-style:none}.fill-btn-blue:hover{background:#145fa9;transition:.4s ease-in}.fill-btn-blue:active{background:#0b3d6f;transition:.4s ease-in-out}.fill-btn-red{background:#dd1313;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#f0f8ff;border-radius:5px;font-size:12px;cursor:pointer;border-style:none}.fill-btn-red:hover{background:#f42020;transition:.4s ease-in}.fill-btn-red:active{background:#a70d0d;transition:.4s ease-in-out}.fill-btn-orange{background:#ff5f33;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#f0f8ff;border-radius:5px;font-size:12px;cursor:pointer;border-style:none}.fill-btn-orange:hover{background:#ff7149;transition:.4s ease-in}.fill-btn-orange:active{background:#d74f2a;transition:.4s ease-in-out}.fill-btn-yellow{background:#fbb000;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#f0f8ff;border-radius:5px;font-size:12px;cursor:pointer;border-style:none}.fill-btn-yellow:hover{background:#ffbc20;transition:.4s ease-in}.fill-btn-yellow:active{background:#d79700;transition:.4s ease-in-out}.fill-btn-green{background:#10b95c;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#f0f8ff;border-radius:5px;font-size:12px;cursor:pointer;border-style:none}.fill-btn-green:hover{background:#11c462;transition:.4s ease-in}.fill-btn-green:active{background:#0c9248;transition:.4s ease-in-out}.outline-btn-blue{background:none;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#0f4c8a;border-radius:5px;font-size:12px;cursor:pointer;border-style:solid;border-color:#0f4c8a;border-width:1px}.outline-btn-blue:hover{background:#74b1ef;color:#f0f8ff;transition:.4s ease-in}.outline-btn-blue:active{background:#0b3d6f;transition:.4s ease-in-out}.outline-btn-red{background:none;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#dd1313;border-radius:5px;font-size:12px;cursor:pointer;border-style:solid;border-color:#dd1313;border-width:1px}.outline-btn-red:hover{background:#f42020;color:#f0f8ff;transition:.4s ease-in}.outline-btn-red:active{background:#a70d0d;transition:.4s ease-in-out}.outline-btn-orange{background:none;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#ff5f33;border-radius:5px;font-size:12px;cursor:pointer;border-style:solid;border-color:#ff5f33;border-width:1px}.outline-btn-orange:hover{background:#ff7149;color:#f0f8ff;transition:.4s ease-in}.outline-btn-orange:active{background:#d74f2a;transition:.4s ease-in-out}.outline-btn-yellow{background:none;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#d0950a;border-radius:5px;font-size:12px;cursor:pointer;border-style:solid;border-color:#fbb000;border-width:1px}.outline-btn-yellow:hover{background:#ffbc20;color:#f0f8ff;transition:.4s ease-in}.outline-btn-yellow:active{background:#d79700;transition:.4s ease-in-out}.outline-btn-green{background:none;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#0b984a;border-radius:5px;font-size:12px;cursor:pointer;border-style:solid;border-color:#10b95c;border-width:1px}.outline-btn-green:hover{background:#e1eee6;color:#097b3d;transition:.4s ease-in}.outline-btn-green:active{background:#0c9248;transition:.4s ease-in-out}.fill-btn-disabled[disabled]{cursor:not-allowed;background:#bfbfbf;color:#989898}.outline-btn-disabled[disabled]{cursor:not-allowed;background:none;border-style:solid;border-color:#bfbfbf;border-width:1px;color:#989898}\n"], dependencies: [{ kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: BeButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'be-button', template: "<button *ngIf=\"type=='fill' && color=='blue'\" class=\"fill-btn-blue fill-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\"\n[disabled]=\"disabledButton\"\n>{{label}}</button>\n\n<button *ngIf=\"type=='fill' && color=='red'\" class=\"fill-btn-red fill-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\" \n[disabled]=\"disabledButton\"\n>{{label}}</button>\n\n<button *ngIf=\"type=='fill' && color=='orange'\" class=\"fill-btn-orange fill-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\" \n[disabled]=\"disabledButton\"\n>{{label}}</button>\n\n<button *ngIf=\"type=='fill' && color=='yellow'\" class=\"fill-btn-yellow fill-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\" \n[disabled]=\"disabledButton\" \n>{{label}}</button>\n\n<button *ngIf=\"type=='fill' && color=='green'\" class=\"fill-btn-green fill-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\" \n[disabled]=\"disabledButton\" \n>{{label}}</button>\n\n<!-- outline -->\n<button *ngIf=\"type=='outline' && color=='blue'\" class=\"outline-btn-blue outline-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\" \n[disabled]=\"disabledButton\"\n>{{label}}</button>\n\n<button *ngIf=\"type=='outline' && color=='red'\" class=\"outline-btn-red outline-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\" \n[disabled]=\"disabledButton\"\n>{{label}}</button>\n\n<button *ngIf=\"type=='outline' && color=='orange'\" class=\"outline-btn-orange outline-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\" \n[disabled]=\"disabledButton\"\n>{{label}}</button>\n\n<button *ngIf=\"type=='outline' && color=='yellow'\" class=\"outline-btn-yellow outline-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\" \n[disabled]=\"disabledButton\"\n>{{label}}</button>\n\n<button *ngIf=\"type=='outline' && color=='green'\" class=\"outline-btn-green outline-btn-disabled\"\nid=\"appButton\"\n(click)=\"actionClick(label)\" \n[disabled]=\"disabledButton\"\n>{{label}}</button>\n\n\n", styles: [".fill-btn-blue{background:#0F4C8A;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#f0f8ff;border-radius:5px;font-size:12px;cursor:pointer;border-style:none}.fill-btn-blue:hover{background:#145fa9;transition:.4s ease-in}.fill-btn-blue:active{background:#0b3d6f;transition:.4s ease-in-out}.fill-btn-red{background:#dd1313;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#f0f8ff;border-radius:5px;font-size:12px;cursor:pointer;border-style:none}.fill-btn-red:hover{background:#f42020;transition:.4s ease-in}.fill-btn-red:active{background:#a70d0d;transition:.4s ease-in-out}.fill-btn-orange{background:#ff5f33;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#f0f8ff;border-radius:5px;font-size:12px;cursor:pointer;border-style:none}.fill-btn-orange:hover{background:#ff7149;transition:.4s ease-in}.fill-btn-orange:active{background:#d74f2a;transition:.4s ease-in-out}.fill-btn-yellow{background:#fbb000;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#f0f8ff;border-radius:5px;font-size:12px;cursor:pointer;border-style:none}.fill-btn-yellow:hover{background:#ffbc20;transition:.4s ease-in}.fill-btn-yellow:active{background:#d79700;transition:.4s ease-in-out}.fill-btn-green{background:#10b95c;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#f0f8ff;border-radius:5px;font-size:12px;cursor:pointer;border-style:none}.fill-btn-green:hover{background:#11c462;transition:.4s ease-in}.fill-btn-green:active{background:#0c9248;transition:.4s ease-in-out}.outline-btn-blue{background:none;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#0f4c8a;border-radius:5px;font-size:12px;cursor:pointer;border-style:solid;border-color:#0f4c8a;border-width:1px}.outline-btn-blue:hover{background:#74b1ef;color:#f0f8ff;transition:.4s ease-in}.outline-btn-blue:active{background:#0b3d6f;transition:.4s ease-in-out}.outline-btn-red{background:none;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#dd1313;border-radius:5px;font-size:12px;cursor:pointer;border-style:solid;border-color:#dd1313;border-width:1px}.outline-btn-red:hover{background:#f42020;color:#f0f8ff;transition:.4s ease-in}.outline-btn-red:active{background:#a70d0d;transition:.4s ease-in-out}.outline-btn-orange{background:none;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#ff5f33;border-radius:5px;font-size:12px;cursor:pointer;border-style:solid;border-color:#ff5f33;border-width:1px}.outline-btn-orange:hover{background:#ff7149;color:#f0f8ff;transition:.4s ease-in}.outline-btn-orange:active{background:#d74f2a;transition:.4s ease-in-out}.outline-btn-yellow{background:none;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#d0950a;border-radius:5px;font-size:12px;cursor:pointer;border-style:solid;border-color:#fbb000;border-width:1px}.outline-btn-yellow:hover{background:#ffbc20;color:#f0f8ff;transition:.4s ease-in}.outline-btn-yellow:active{background:#d79700;transition:.4s ease-in-out}.outline-btn-green{background:none;padding-inline:13px;padding-block:6px;display:flex;width:-moz-fit-content;width:fit-content;flex-direction:column;align-items:center;justify-content:center;color:#0b984a;border-radius:5px;font-size:12px;cursor:pointer;border-style:solid;border-color:#10b95c;border-width:1px}.outline-btn-green:hover{background:#e1eee6;color:#097b3d;transition:.4s ease-in}.outline-btn-green:active{background:#0c9248;transition:.4s ease-in-out}.fill-btn-disabled[disabled]{cursor:not-allowed;background:#bfbfbf;color:#989898}.outline-btn-disabled[disabled]{cursor:not-allowed;background:none;border-style:solid;border-color:#bfbfbf;border-width:1px;color:#989898}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], type: [{
                type: Input
            }], color: [{
                type: Input
            }], disabledButton: [{
                type: Input
            }], hideButton: [{
                type: Input
            }], rowData: [{
                type: Input
            }], btnClick: [{
                type: Output
            }] } });

class ContextMenuService {
    constructor() {
        this.contextMenuItems = [];
    }
    contextMenu(contextMenu) {
        this.contextMenuItems = [];
        this.contextMenuItems = contextMenu;
    }
}
ContextMenuService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ContextMenuService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
ContextMenuService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ContextMenuService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ContextMenuService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class BeContextMenuComponent {
    constructor(contextMenu) {
        this.contextMenu = contextMenu;
        this.x = 0;
        this.y = 0;
        this.toggleExport = true;
        this.excelExport = new EventEmitter();
        this.csvExport = new EventEmitter();
    }
    excelExportDownload() { this.excelExport.emit(); }
    csvExportDownload() { this.csvExport.emit(); }
}
BeContextMenuComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: BeContextMenuComponent, deps: [{ token: ContextMenuService }], target: i0.ɵɵFactoryTarget.Component });
BeContextMenuComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: BeContextMenuComponent, selector: "be-context-menu", inputs: { x: "x", y: "y", toggleExport: "toggleExport" }, outputs: { excelExport: "excelExport", csvExport: "csvExport" }, ngImport: i0, template: "<div class=\"contextmenu\" [ngStyle]=\"{'left.px': x, 'top.px': y}\">\n    <div *ngIf=\"toggleExport\">\n        <span class=\"menu-item\" (click)=\"excelExportDownload()\"><i class=\"fa-regular fa-file-excel\"></i><span class=\"label\">Excel Export</span></span>\n        <span class=\"menu-item\" (click)=\"csvExportDownload()\"><i class=\"fa-solid fa-file-csv\"></i><span class=\"label\">CSV Export</span></span>\n    </div>\n\n    <span class=\"separator\"></span>\n\n    <div *ngFor=\"let item of contextMenu.contextMenuItems\">\n      <span class=\"menu-item\" (click)=\"item.action()\">\n        <i class=\"{{ item.icon?.className }}\" [ngStyle]=\"{ 'color': item.icon?.color }\"></i>\n        <span class=\"label\">{{ item.label }}</span>\n      </span>\n    </div>\n</div>\n", styles: [".contextmenu{display:flex;flex-direction:column;position:fixed;z-index:1000;background:rgb(248,248,248);box-shadow:0 5px 20px 5px #0000001a;border-radius:3px;padding-block:8px;border-style:solid;border-color:#e4e4e4;border-width:.7px;width:300px;font-size:15px;transition:.1s ease-in}.menu-item{padding-inline:20px;padding-block:10px;gap:15px;cursor:pointer;display:flex;align-items:center;color:#252525}.menu-item:hover{background:rgba(15,76,138,.06);transition:.1s ease-in}i{font-size:13pt}.separator{width:100%;height:.7px;background:rgb(210,210,210);margin-block:7px}\n"], dependencies: [{ kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: BeContextMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'be-context-menu', template: "<div class=\"contextmenu\" [ngStyle]=\"{'left.px': x, 'top.px': y}\">\n    <div *ngIf=\"toggleExport\">\n        <span class=\"menu-item\" (click)=\"excelExportDownload()\"><i class=\"fa-regular fa-file-excel\"></i><span class=\"label\">Excel Export</span></span>\n        <span class=\"menu-item\" (click)=\"csvExportDownload()\"><i class=\"fa-solid fa-file-csv\"></i><span class=\"label\">CSV Export</span></span>\n    </div>\n\n    <span class=\"separator\"></span>\n\n    <div *ngFor=\"let item of contextMenu.contextMenuItems\">\n      <span class=\"menu-item\" (click)=\"item.action()\">\n        <i class=\"{{ item.icon?.className }}\" [ngStyle]=\"{ 'color': item.icon?.color }\"></i>\n        <span class=\"label\">{{ item.label }}</span>\n      </span>\n    </div>\n</div>\n", styles: [".contextmenu{display:flex;flex-direction:column;position:fixed;z-index:1000;background:rgb(248,248,248);box-shadow:0 5px 20px 5px #0000001a;border-radius:3px;padding-block:8px;border-style:solid;border-color:#e4e4e4;border-width:.7px;width:300px;font-size:15px;transition:.1s ease-in}.menu-item{padding-inline:20px;padding-block:10px;gap:15px;cursor:pointer;display:flex;align-items:center;color:#252525}.menu-item:hover{background:rgba(15,76,138,.06);transition:.1s ease-in}i{font-size:13pt}.separator{width:100%;height:.7px;background:rgb(210,210,210);margin-block:7px}\n"] }]
        }], ctorParameters: function () { return [{ type: ContextMenuService }]; }, propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }], toggleExport: [{
                type: Input
            }], excelExport: [{
                type: Output
            }], csvExport: [{
                type: Output
            }] } });

class BeGridComponent {
    constructor(liveAnnouncer) {
        this.liveAnnouncer = liveAnnouncer;
        this.width = "0";
        this.height = "0";
        this.rowData = new BehaviorSubject([]);
        this.defColumns = [];
        this.paging = false;
        this.filter = false;
        this.actionColumnSticky = false;
        this.columnPanel = false;
        this.toggleSearchResult = false;
        this.pageSizeOptions = [];
        this.xColumnsExport = [];
        this.toggleExport = true;
        this.exportFileName = "table-export";
        this.multiRowSelect = false;
        this.exportActions = false;
        this.showLoader = false;
        this.showLoaderMsg = { text: true, value: "loading..." };
        //emit events
        this.rowClick = new EventEmitter();
        this.onActionButton = new EventEmitter();
        this.rowSelection = new EventEmitter();
        this.search = new EventEmitter();
        this.pageChange = new EventEmitter();
        this.displayedColumns = [];
        this.tableRowData = new MatTableDataSource();
        this.selection = new SelectionModel(true, []);
        this.additionalColumns = [];
        this.contextmenu = false;
        this.contextmenuX = 0;
        this.contextmenuY = 0;
    }
    ngOnInit() {
        this.displayedColumns = this.defColumns.map(cols => cols.name);
        this.rowData.subscribe((data) => {
            this.tableRowData.data = data;
            this.additionalColumns = Object.keys(Object.assign({}, data[0]));
        });
    }
    // column reassign sorted data
    ngAfterViewInit() {
        this.tableRowData.sort = this.sort;
        this.tableRowData.paginator = this.paginator;
    }
    // when row/cell is clicked
    onRowClick(row, event) {
        if (event.target.id != "appButton" && event.target.id != "actionRow") {
            this.rowClick.emit(row);
        }
    }
    // when action button on a row is clicked
    buttonClick(event) {
        this.onActionButton.emit(event);
    }
    // filtering/searching through table
    applyFilter(event) {
        const filterValue = event.target.value;
        this.tableRowData.filter = filterValue.trim().toLowerCase();
        this.search.emit(filterValue);
    }
    onSearch() {
        // searched value result
        this.search.emit(this.tableRowData.filter);
    }
    // column sort annouce sort change
    announceSortChange(sortState) {
        if (sortState.direction) {
            this.liveAnnouncer.announce(`Sorted ${sortState.direction}ending`);
        }
        else {
            this.liveAnnouncer.announce('Sorting cleared');
        }
    }
    // on drag column header
    drop(event) {
        moveItemInArray(this.displayedColumns, event.previousIndex, event.currentIndex);
    }
    // checkbox for cells and headers
    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected() {
        const numSelected = this.selection.selected.length;
        const numRows = this.tableRowData.data.length;
        return numSelected === numRows;
    }
    /** Selects all rows if they are not all selected; otherwise clear selection. */
    toggleAllRows() {
        if (this.isAllSelected()) {
            this.selection.clear();
            return;
        }
        this.selection.select(...this.tableRowData.data);
    }
    /** The label for the checkbox on the passed row */
    checkboxLabel(row) {
        if (!row) {
            return `${this.isAllSelected() ? 'deselect' : 'select'} all`;
        }
        return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.position + 1}`;
    }
    onRowSelection(selectedRow, singleRow) {
        if (singleRow && !this.multiRowSelect) {
            this.rowSelection.emit({ selectedRows: [selectedRow] });
        }
        else {
            this.rowSelection.emit({ selectedRows: this.selection.selected });
        }
        //on row selection, hide context menu
        this.hideContextMenu();
    }
    // column panel
    // checking all displayedColumns in the column panel
    isDisplayedColumns(column) {
        let isChecked = this.displayedColumns.find((data) => data === column);
        return !!isChecked;
    }
    // adding and removing columns from displayedColumns
    addColumn(column) {
        let isAvailable = this.displayedColumns.find((data) => data === column);
        if (isAvailable != undefined) {
            this.displayedColumns = this.displayedColumns.filter((data) => data != column);
        }
        else {
            let insertAtIndex = this.displayedColumns.length - 1;
            let checkColumnExist = this.defColumns.find((data) => data.name === column);
            !checkColumnExist ? this.defColumns.push({ name: column }) : "";
            this.displayedColumns.splice(insertAtIndex, 0, column);
        }
    }
    //activates the menu with the coordinates
    onRightClick(event) {
        this.contextmenuX = event.clientX;
        this.contextmenuY = event.clientY;
        this.contextmenu = true;
    }
    //disables the menu
    hideContextMenu() {
        this.contextmenu = false;
    }
    //emit current page size
    pageSizeChange(page) {
        this.pageChange.emit(page);
    }
}
BeGridComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: BeGridComponent, deps: [{ token: i1.LiveAnnouncer }], target: i0.ɵɵFactoryTarget.Component });
BeGridComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: BeGridComponent, selector: "be-grid", inputs: { width: "width", height: "height", rowData: "rowData", defColumns: "defColumns", paging: "paging", filter: "filter", actionColumnSticky: "actionColumnSticky", columnPanel: "columnPanel", toggleSearchResult: "toggleSearchResult", pageSizeOptions: "pageSizeOptions", xColumnsExport: "xColumnsExport", toggleExport: "toggleExport", exportFileName: "exportFileName", multiRowSelect: "multiRowSelect", exportActions: "exportActions", showLoader: "showLoader", showLoaderMsg: "showLoaderMsg" }, outputs: { rowClick: "rowClick", onActionButton: "onActionButton", rowSelection: "rowSelection", search: "search", pageChange: "pageChange" }, viewQueries: [{ propertyName: "sort", first: true, predicate: MatSort, descendants: true }, { propertyName: "paginator", first: true, predicate: MatPaginator, descendants: true }], ngImport: i0, template: "<div class=\"main-wrapper\" (click)=\"hideContextMenu()\" oncontextmenu=\"return false;\">\n\n    <!-- search table input field-->\n    <div class=\"top-items\">\n        <div class=\"search-wrapper\" *ngIf=\"filter\">\n            <input class=\"search-input\" type=\"search\"  placeholder=\"Search\" (search)=\"applyFilter($event)\" (keyup)=\"applyFilter($event)\" #input>\n            <i (click)=\"onSearch()\" class=\"fa-solid fa-magnifying-glass\"></i>\n        </div>\n        <div class=\"top-action-items\" *ngIf=\"exportActions\">\n            <span (click)=\"exporter.exportTable('xlsx', {fileName: exportFileName})\" ><i class=\"fa-regular fa-file-excel\"></i> Excel</span>\n            <span (click)=\"exporter.exportTable('csv', {fileName: exportFileName})\"><i class=\"fa-solid fa-file-csv\"></i> CSV</span>\n        </div>\n    </div>\n\n    <div class=\"table-column-panel-wrapper\" (contextmenu)=\"onRightClick($event)\" [ngStyle]=\"{width: width, height: height}\">\n\n        <!-- scrollable table wrapper -->\n        <section class=\"table-scrollable mat-elevation-z8\" tabindex=\"0\" >\n\n            <!-- context menu -->\n            <be-context-menu\n                    *ngIf=\"contextmenu\"\n                    [x]=\"contextmenuX\"\n                    [y]=\"contextmenuY\"\n                    [toggleExport]=\"toggleExport\"\n                    (excelExport)=\"exporter.exportTable('xlsx', {fileName: exportFileName})\"\n                    (csvExport)=\"exporter.exportTable('csv', {fileName: exportFileName})\"\n            ></be-context-menu>\n\n            <!-- table def -->\n            <table mat-table\n                   [dataSource]=\"tableRowData\"\n                   class=\"mat-elevation-z8\"\n                   matSort\n                   cdkDropList\n                   (matSortChange)=\"announceSortChange($event)\"\n                   cdkDropListOrientation=\"horizontal\"\n                   (cdkDropListDropped)=\"drop($event)\"\n                   matTableExporter\n                   #exporter=\"matTableExporter\"\n                   [hiddenColumns]=\"xColumnsExport\">\n\n                <!-- column name definition -->\n                <ng-container *ngFor=\"let column of defColumns\" >\n                    <ng-container matColumnDef=\"{{ column.name }}\" [stickyEnd]=\"column.name == 'action' && actionColumnSticky\">\n\n                        <!-- headers here -->\n                        <th mat-header-cell *matHeaderCellDef cdkDrag mat-sort-header disabled=\"{{!column.columnSortable}}\" sortActionDescription=\"{{'Sort by '+column.name}}\">\n                            <mat-checkbox *ngIf=\"column.name != 'action' && column.rowSelection && multiRowSelect\" (change)=\"$event ? toggleAllRows() : null\"\n                                          [checked]=\"selection.hasValue() && isAllSelected()\"\n                                          [indeterminate]=\"selection.hasValue() && !isAllSelected()\"\n                                          [color]=\"'primary'\"\n                                          (click)=\"onRowSelection()\"\n                                          [aria-label]=\"checkboxLabel()\">\n                            </mat-checkbox>\n                            <ng-container *ngIf=\"column.label; then label; else name\"></ng-container>\n                            <ng-template #label>{{column.label}}</ng-template>\n                            <ng-template #name>{{column.name | titlecase}}</ng-template>\n                        </th>\n\n                        <!-- cell -->\n                        <td mat-cell *matCellDef=\"let element\">\n\n                            <!-- row data here -->\n                            <span  class=\"cell-style\">\n                                <mat-checkbox *ngIf=\"column.name != 'action' && column.rowSelection && multiRowSelect\"\n                                              (click)=\"$event.stopPropagation(); onRowSelection()\"\n                                              (change)=\"$event ? selection.toggle(element) : null\"\n                                              [checked]=\"selection.isSelected(element)\"\n                                              [color]=\"'primary'\"\n                                              [aria-label]=\"checkboxLabel(element)\">\n                                </mat-checkbox>\n                                        <!-- cell style -->\n                                <span [ngStyle]=\"column.hasOwnProperty('cellStyle')? column.cellStyle(element): {}\">{{ element[column.name] }}</span>\n                                        <!-- cell flag -->\n                                <span *ngIf=\"column.hasOwnProperty('cellFlag')\" [ngStyle]=\"column.hasOwnProperty('cellFlag')? column.cellFlag(element).style:{}\" class=\"cell-flag\">{{column.cellFlag(element).flagText}}</span>\n                            </span>\n\n                            <!-- action button here -->\n                            <span class=\"action-btns\" *ngIf=\"column.actionButtons\">\n                                <be-button *ngFor=\"let actionButton of column.actionButtons\"\n                                            id=\"actionRow\"\n                                            [label]=\"actionButton.label\"\n                                            [rowData]=\"element\"\n                                            [type]=\"actionButton.type\"\n                                            [color]=\"actionButton.color\"\n                                            [disabledButton]=\"actionButton.hasOwnProperty('disabledButton') && actionButton.disabledButton(element)\"\n                                            [hidden]=\"actionButton.hasOwnProperty('hideButton') && actionButton.hideButton(element)\"\n                                            (btnClick)=\"buttonClick($event)\"\n                                ></be-button>\n                            </span>\n                        </td>\n                    </ng-container>\n                </ng-container>\n\n                <!-- tr for rows and headers -->\n                <tr mat-header-row *matHeaderRowDef=\"displayedColumns; sticky: true\"></tr>\n                <tr mat-row *matRowDef=\"let row; columns: displayedColumns;\" (contextmenu)=\"onRowSelection(row, true)\" (click)=\"onRowClick(row, $event)\"></tr>\n\n                <!-- no rows/data -->\n                <tr class=\"mat-row\" *matNoDataRow >\n                    <td colspan=\"12\" class=\"mat-cell no-data\" *ngIf=\"showLoader && !showLoaderMsg.text\"><img [src]=\"showLoaderMsg.value\" width=\"150\" alt=\"loading...\"></td>\n                    <td colspan=\"12\" class=\"mat-cell no-data\" *ngIf=\"showLoader && showLoaderMsg.text\">{{ showLoaderMsg.value }}</td>\n                    <td colspan=\"12\" class=\"mat-cell no-data\" *ngIf=\"!showLoader\">No data available</td>\n                </tr>\n            </table>\n        </section>\n\n        <!-- column panel -->\n        <div class=\"column-panel\" *ngIf=\"columnPanel\">\n            <span class=\"colum-panel-title\">Column Panel</span>\n            <div class=\"column-panel-list\">\n                <mat-checkbox\n                        *ngFor=\"let column of additionalColumns\"\n                        [checked]=\"isDisplayedColumns(column)\"\n                        (click)=\"addColumn(column)\"\n                        [color]=\"'primary'\"\n                >{{ column | titlecase }}</mat-checkbox>\n            </div>\n        </div>\n    </div>\n\n    <!-- pagenatin here -->\n    <mat-paginator *ngIf=\"paging\"\n                   [pageSizeOptions]=\"pageSizeOptions\"\n                   showFirstLastButtons\n                   aria-label=\"Select page of periodic elements\"\n                   (page)=\"pageSizeChange($event)\">\n    </mat-paginator>\n</div>\n", styles: [".top-items{display:grid;grid-template-columns:auto auto;justify-content:space-between;align-items:center}.search-wrapper{display:flex;flex-direction:row;align-items:center;font-size:16pt;margin-bottom:10px;border-style:solid;border-color:#d9d9d9;color:#797979;width:-moz-fit-content;width:fit-content;padding-inline-start:10px;border-radius:2px}.search-input{width:300px;height:40px;outline:none;font-size:14pt;color:#5e5e5e;border-style:none}.fa-magnifying-glass{display:flex;flex-direction:row;background:rgb(217,217,217);color:#828282;padding-inline:8px;align-items:center;cursor:pointer;height:40px}.fa-magnifying-glass:hover{background:rgb(224,224,224);transition:.3s ease-in}.fa-magnifying-glass:active{background:rgb(217,217,217);transition:.3s ease-out}.top-action-items{display:flex;flex-direction:row;column-gap:10px}.top-action-items span{padding-inline:8px;padding-block:5px;border-color:#c2c2c2;color:#797979;background:rgb(233,233,233);border-style:solid;border-radius:3px;border-width:1px;cursor:pointer}.top-action-items span:hover{background:rgb(241,241,241);transition:.3s ease-in-out}.top-action-items span:active{background:rgb(220,220,220);transition:.3s ease-in-out}.table-column-panel-wrapper{display:flex;flex-direction:row}.column-panel{display:flex;flex-direction:column;width:200px;height:inherit;overflow:hidden;border-right-style:solid;border-right-width:2px;border-right-color:#d9d9d9;border-top-style:solid;border-top-width:2px;border-top-color:#d9d9d9;border-bottom-style:solid;border-bottom-width:2px;border-bottom-color:#d9d9d9}.colum-panel-title{background:rgb(245,245,245);padding:17.5px;position:static;width:100%;border-bottom-style:solid;border-bottom-width:2px;border-bottom-color:#d9d9d9}.column-panel-list{display:flex;flex-direction:column;overflow:auto}.table-scrollable{width:inherit;height:inherit;overflow:auto;box-shadow:none;border-style:solid;border-width:2px;border-color:#d9d9d9}table{width:inherit;box-shadow:none}.mat-mdc-table{white-space:nowrap!important}table th{border-bottom-style:solid;border-bottom-width:2px;background-color:#f5f5f5;border-bottom-color:#d9d9d9}.mat-mdc-row:hover .mat-mdc-cell{background:rgb(250,250,250);cursor:default}.no-data{text-align:center;padding:100px;color:#aaa}.action-btns{display:flex;flex-direction:row;align-items:center;column-gap:10px}.cell-style{display:flex;flex-direction:row;align-items:center;column-gap:5px}.cell-flag{padding:5px;font-size:11px;border-radius:3px}::ng-deep .mdc-checkbox__background{border-color:#0f4c8a!important;padding:3px!important}::ng-deep .mdc-checkbox__checkmark-path{stroke-width:3px!important}::ng-deep .search-wrapper{border-width:2px}\n"], dependencies: [{ kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: i3.MatTable, selector: "mat-table, table[mat-table]", exportAs: ["matTable"] }, { kind: "directive", type: i3.MatHeaderCellDef, selector: "[matHeaderCellDef]" }, { kind: "directive", type: i3.MatHeaderRowDef, selector: "[matHeaderRowDef]", inputs: ["matHeaderRowDef", "matHeaderRowDefSticky"] }, { kind: "directive", type: i3.MatColumnDef, selector: "[matColumnDef]", inputs: ["sticky", "matColumnDef"] }, { kind: "directive", type: i3.MatCellDef, selector: "[matCellDef]" }, { kind: "directive", type: i3.MatRowDef, selector: "[matRowDef]", inputs: ["matRowDefColumns", "matRowDefWhen"] }, { kind: "directive", type: i3.MatHeaderCell, selector: "mat-header-cell, th[mat-header-cell]" }, { kind: "directive", type: i3.MatCell, selector: "mat-cell, td[mat-cell]" }, { kind: "component", type: i3.MatHeaderRow, selector: "mat-header-row, tr[mat-header-row]", exportAs: ["matHeaderRow"] }, { kind: "component", type: i3.MatRow, selector: "mat-row, tr[mat-row]", exportAs: ["matRow"] }, { kind: "directive", type: i3.MatNoDataRow, selector: "ng-template[matNoDataRow]" }, { kind: "component", type: i4.MatCheckbox, selector: "mat-checkbox", inputs: ["disableRipple", "color", "tabIndex"], exportAs: ["matCheckbox"] }, { kind: "directive", type: i5.MatSort, selector: "[matSort]", inputs: ["matSortDisabled", "matSortActive", "matSortStart", "matSortDirection", "matSortDisableClear"], outputs: ["matSortChange"], exportAs: ["matSort"] }, { kind: "component", type: i5.MatSortHeader, selector: "[mat-sort-header]", inputs: ["disabled", "mat-sort-header", "arrowPosition", "start", "sortActionDescription", "disableClear"], exportAs: ["matSortHeader"] }, { kind: "component", type: i6.MatPaginator, selector: "mat-paginator", inputs: ["disabled"], exportAs: ["matPaginator"] }, { kind: "directive", type: i7.CdkDropList, selector: "[cdkDropList], cdk-drop-list", inputs: ["cdkDropListConnectedTo", "cdkDropListData", "cdkDropListOrientation", "id", "cdkDropListLockAxis", "cdkDropListDisabled", "cdkDropListSortingDisabled", "cdkDropListEnterPredicate", "cdkDropListSortPredicate", "cdkDropListAutoScrollDisabled", "cdkDropListAutoScrollStep"], outputs: ["cdkDropListDropped", "cdkDropListEntered", "cdkDropListExited", "cdkDropListSorted"], exportAs: ["cdkDropList"] }, { kind: "directive", type: i7.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i8.MatTableExporterDirective, selector: "[matTableExporter]", exportAs: ["matTableExporter"] }, { kind: "component", type: BeButtonComponent, selector: "be-button", inputs: ["label", "type", "color", "disabledButton", "hideButton", "rowData"], outputs: ["btnClick"] }, { kind: "component", type: BeContextMenuComponent, selector: "be-context-menu", inputs: ["x", "y", "toggleExport"], outputs: ["excelExport", "csvExport"] }, { kind: "pipe", type: i2.TitleCasePipe, name: "titlecase" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: BeGridComponent, decorators: [{
            type: Component,
            args: [{ selector: 'be-grid', template: "<div class=\"main-wrapper\" (click)=\"hideContextMenu()\" oncontextmenu=\"return false;\">\n\n    <!-- search table input field-->\n    <div class=\"top-items\">\n        <div class=\"search-wrapper\" *ngIf=\"filter\">\n            <input class=\"search-input\" type=\"search\"  placeholder=\"Search\" (search)=\"applyFilter($event)\" (keyup)=\"applyFilter($event)\" #input>\n            <i (click)=\"onSearch()\" class=\"fa-solid fa-magnifying-glass\"></i>\n        </div>\n        <div class=\"top-action-items\" *ngIf=\"exportActions\">\n            <span (click)=\"exporter.exportTable('xlsx', {fileName: exportFileName})\" ><i class=\"fa-regular fa-file-excel\"></i> Excel</span>\n            <span (click)=\"exporter.exportTable('csv', {fileName: exportFileName})\"><i class=\"fa-solid fa-file-csv\"></i> CSV</span>\n        </div>\n    </div>\n\n    <div class=\"table-column-panel-wrapper\" (contextmenu)=\"onRightClick($event)\" [ngStyle]=\"{width: width, height: height}\">\n\n        <!-- scrollable table wrapper -->\n        <section class=\"table-scrollable mat-elevation-z8\" tabindex=\"0\" >\n\n            <!-- context menu -->\n            <be-context-menu\n                    *ngIf=\"contextmenu\"\n                    [x]=\"contextmenuX\"\n                    [y]=\"contextmenuY\"\n                    [toggleExport]=\"toggleExport\"\n                    (excelExport)=\"exporter.exportTable('xlsx', {fileName: exportFileName})\"\n                    (csvExport)=\"exporter.exportTable('csv', {fileName: exportFileName})\"\n            ></be-context-menu>\n\n            <!-- table def -->\n            <table mat-table\n                   [dataSource]=\"tableRowData\"\n                   class=\"mat-elevation-z8\"\n                   matSort\n                   cdkDropList\n                   (matSortChange)=\"announceSortChange($event)\"\n                   cdkDropListOrientation=\"horizontal\"\n                   (cdkDropListDropped)=\"drop($event)\"\n                   matTableExporter\n                   #exporter=\"matTableExporter\"\n                   [hiddenColumns]=\"xColumnsExport\">\n\n                <!-- column name definition -->\n                <ng-container *ngFor=\"let column of defColumns\" >\n                    <ng-container matColumnDef=\"{{ column.name }}\" [stickyEnd]=\"column.name == 'action' && actionColumnSticky\">\n\n                        <!-- headers here -->\n                        <th mat-header-cell *matHeaderCellDef cdkDrag mat-sort-header disabled=\"{{!column.columnSortable}}\" sortActionDescription=\"{{'Sort by '+column.name}}\">\n                            <mat-checkbox *ngIf=\"column.name != 'action' && column.rowSelection && multiRowSelect\" (change)=\"$event ? toggleAllRows() : null\"\n                                          [checked]=\"selection.hasValue() && isAllSelected()\"\n                                          [indeterminate]=\"selection.hasValue() && !isAllSelected()\"\n                                          [color]=\"'primary'\"\n                                          (click)=\"onRowSelection()\"\n                                          [aria-label]=\"checkboxLabel()\">\n                            </mat-checkbox>\n                            <ng-container *ngIf=\"column.label; then label; else name\"></ng-container>\n                            <ng-template #label>{{column.label}}</ng-template>\n                            <ng-template #name>{{column.name | titlecase}}</ng-template>\n                        </th>\n\n                        <!-- cell -->\n                        <td mat-cell *matCellDef=\"let element\">\n\n                            <!-- row data here -->\n                            <span  class=\"cell-style\">\n                                <mat-checkbox *ngIf=\"column.name != 'action' && column.rowSelection && multiRowSelect\"\n                                              (click)=\"$event.stopPropagation(); onRowSelection()\"\n                                              (change)=\"$event ? selection.toggle(element) : null\"\n                                              [checked]=\"selection.isSelected(element)\"\n                                              [color]=\"'primary'\"\n                                              [aria-label]=\"checkboxLabel(element)\">\n                                </mat-checkbox>\n                                        <!-- cell style -->\n                                <span [ngStyle]=\"column.hasOwnProperty('cellStyle')? column.cellStyle(element): {}\">{{ element[column.name] }}</span>\n                                        <!-- cell flag -->\n                                <span *ngIf=\"column.hasOwnProperty('cellFlag')\" [ngStyle]=\"column.hasOwnProperty('cellFlag')? column.cellFlag(element).style:{}\" class=\"cell-flag\">{{column.cellFlag(element).flagText}}</span>\n                            </span>\n\n                            <!-- action button here -->\n                            <span class=\"action-btns\" *ngIf=\"column.actionButtons\">\n                                <be-button *ngFor=\"let actionButton of column.actionButtons\"\n                                            id=\"actionRow\"\n                                            [label]=\"actionButton.label\"\n                                            [rowData]=\"element\"\n                                            [type]=\"actionButton.type\"\n                                            [color]=\"actionButton.color\"\n                                            [disabledButton]=\"actionButton.hasOwnProperty('disabledButton') && actionButton.disabledButton(element)\"\n                                            [hidden]=\"actionButton.hasOwnProperty('hideButton') && actionButton.hideButton(element)\"\n                                            (btnClick)=\"buttonClick($event)\"\n                                ></be-button>\n                            </span>\n                        </td>\n                    </ng-container>\n                </ng-container>\n\n                <!-- tr for rows and headers -->\n                <tr mat-header-row *matHeaderRowDef=\"displayedColumns; sticky: true\"></tr>\n                <tr mat-row *matRowDef=\"let row; columns: displayedColumns;\" (contextmenu)=\"onRowSelection(row, true)\" (click)=\"onRowClick(row, $event)\"></tr>\n\n                <!-- no rows/data -->\n                <tr class=\"mat-row\" *matNoDataRow >\n                    <td colspan=\"12\" class=\"mat-cell no-data\" *ngIf=\"showLoader && !showLoaderMsg.text\"><img [src]=\"showLoaderMsg.value\" width=\"150\" alt=\"loading...\"></td>\n                    <td colspan=\"12\" class=\"mat-cell no-data\" *ngIf=\"showLoader && showLoaderMsg.text\">{{ showLoaderMsg.value }}</td>\n                    <td colspan=\"12\" class=\"mat-cell no-data\" *ngIf=\"!showLoader\">No data available</td>\n                </tr>\n            </table>\n        </section>\n\n        <!-- column panel -->\n        <div class=\"column-panel\" *ngIf=\"columnPanel\">\n            <span class=\"colum-panel-title\">Column Panel</span>\n            <div class=\"column-panel-list\">\n                <mat-checkbox\n                        *ngFor=\"let column of additionalColumns\"\n                        [checked]=\"isDisplayedColumns(column)\"\n                        (click)=\"addColumn(column)\"\n                        [color]=\"'primary'\"\n                >{{ column | titlecase }}</mat-checkbox>\n            </div>\n        </div>\n    </div>\n\n    <!-- pagenatin here -->\n    <mat-paginator *ngIf=\"paging\"\n                   [pageSizeOptions]=\"pageSizeOptions\"\n                   showFirstLastButtons\n                   aria-label=\"Select page of periodic elements\"\n                   (page)=\"pageSizeChange($event)\">\n    </mat-paginator>\n</div>\n", styles: [".top-items{display:grid;grid-template-columns:auto auto;justify-content:space-between;align-items:center}.search-wrapper{display:flex;flex-direction:row;align-items:center;font-size:16pt;margin-bottom:10px;border-style:solid;border-color:#d9d9d9;color:#797979;width:-moz-fit-content;width:fit-content;padding-inline-start:10px;border-radius:2px}.search-input{width:300px;height:40px;outline:none;font-size:14pt;color:#5e5e5e;border-style:none}.fa-magnifying-glass{display:flex;flex-direction:row;background:rgb(217,217,217);color:#828282;padding-inline:8px;align-items:center;cursor:pointer;height:40px}.fa-magnifying-glass:hover{background:rgb(224,224,224);transition:.3s ease-in}.fa-magnifying-glass:active{background:rgb(217,217,217);transition:.3s ease-out}.top-action-items{display:flex;flex-direction:row;column-gap:10px}.top-action-items span{padding-inline:8px;padding-block:5px;border-color:#c2c2c2;color:#797979;background:rgb(233,233,233);border-style:solid;border-radius:3px;border-width:1px;cursor:pointer}.top-action-items span:hover{background:rgb(241,241,241);transition:.3s ease-in-out}.top-action-items span:active{background:rgb(220,220,220);transition:.3s ease-in-out}.table-column-panel-wrapper{display:flex;flex-direction:row}.column-panel{display:flex;flex-direction:column;width:200px;height:inherit;overflow:hidden;border-right-style:solid;border-right-width:2px;border-right-color:#d9d9d9;border-top-style:solid;border-top-width:2px;border-top-color:#d9d9d9;border-bottom-style:solid;border-bottom-width:2px;border-bottom-color:#d9d9d9}.colum-panel-title{background:rgb(245,245,245);padding:17.5px;position:static;width:100%;border-bottom-style:solid;border-bottom-width:2px;border-bottom-color:#d9d9d9}.column-panel-list{display:flex;flex-direction:column;overflow:auto}.table-scrollable{width:inherit;height:inherit;overflow:auto;box-shadow:none;border-style:solid;border-width:2px;border-color:#d9d9d9}table{width:inherit;box-shadow:none}.mat-mdc-table{white-space:nowrap!important}table th{border-bottom-style:solid;border-bottom-width:2px;background-color:#f5f5f5;border-bottom-color:#d9d9d9}.mat-mdc-row:hover .mat-mdc-cell{background:rgb(250,250,250);cursor:default}.no-data{text-align:center;padding:100px;color:#aaa}.action-btns{display:flex;flex-direction:row;align-items:center;column-gap:10px}.cell-style{display:flex;flex-direction:row;align-items:center;column-gap:5px}.cell-flag{padding:5px;font-size:11px;border-radius:3px}::ng-deep .mdc-checkbox__background{border-color:#0f4c8a!important;padding:3px!important}::ng-deep .mdc-checkbox__checkmark-path{stroke-width:3px!important}::ng-deep .search-wrapper{border-width:2px}\n"] }]
        }], ctorParameters: function () { return [{ type: i1.LiveAnnouncer }]; }, propDecorators: { width: [{
                type: Input
            }], height: [{
                type: Input
            }], rowData: [{
                type: Input
            }], defColumns: [{
                type: Input
            }], paging: [{
                type: Input
            }], filter: [{
                type: Input
            }], actionColumnSticky: [{
                type: Input
            }], columnPanel: [{
                type: Input
            }], toggleSearchResult: [{
                type: Input
            }], pageSizeOptions: [{
                type: Input
            }], xColumnsExport: [{
                type: Input
            }], toggleExport: [{
                type: Input
            }], exportFileName: [{
                type: Input
            }], multiRowSelect: [{
                type: Input
            }], exportActions: [{
                type: Input
            }], showLoader: [{
                type: Input
            }], showLoaderMsg: [{
                type: Input
            }], rowClick: [{
                type: Output
            }], onActionButton: [{
                type: Output
            }], rowSelection: [{
                type: Output
            }], search: [{
                type: Output
            }], pageChange: [{
                type: Output
            }], sort: [{
                type: ViewChild,
                args: [MatSort]
            }], paginator: [{
                type: ViewChild,
                args: [MatPaginator]
            }] } });

class BeGridModule {
}
BeGridModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: BeGridModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
BeGridModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: BeGridModule, declarations: [BeGridComponent,
        BeButtonComponent,
        BeContextMenuComponent], imports: [CommonModule,
        MatSlideToggleModule,
        MatTableModule,
        MatCheckboxModule,
        MatInputModule,
        MatFormFieldModule,
        MatIconModule,
        MatSortModule,
        MatPaginatorModule,
        DragDropModule,
        MatTableExporterModule], exports: [BeGridComponent,
        BeButtonComponent,
        BeContextMenuComponent] });
BeGridModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: BeGridModule, providers: [ContextMenuService], imports: [CommonModule,
        MatSlideToggleModule,
        MatTableModule,
        MatCheckboxModule,
        MatInputModule,
        MatFormFieldModule,
        MatIconModule,
        MatSortModule,
        MatPaginatorModule,
        DragDropModule,
        MatTableExporterModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: BeGridModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        BeGridComponent,
                        BeButtonComponent,
                        BeContextMenuComponent,
                    ],
                    imports: [
                        CommonModule,
                        MatSlideToggleModule,
                        MatTableModule,
                        MatCheckboxModule,
                        MatInputModule,
                        MatFormFieldModule,
                        MatIconModule,
                        MatSortModule,
                        MatPaginatorModule,
                        DragDropModule,
                        MatTableExporterModule
                    ],
                    exports: [
                        BeGridComponent,
                        BeButtonComponent,
                        BeContextMenuComponent
                    ],
                    providers: [ContextMenuService],
                    schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
                }]
        }] });

/*
 * Public API Surface of be-grid
 */

/**
 * Generated bundle index. Do not edit.
 */

export { BeButtonComponent, BeContextMenuComponent, BeGridComponent, BeGridModule, ContextMenuService };
//# sourceMappingURL=be-grid.mjs.map
