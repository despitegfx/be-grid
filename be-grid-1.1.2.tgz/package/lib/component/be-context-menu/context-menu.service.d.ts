import { ContextMenu } from "../../model/context-menu";
import * as i0 from "@angular/core";
export declare class ContextMenuService {
    contextMenuItems?: ContextMenu[];
    contextMenu(contextMenu?: ContextMenu[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContextMenuService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ContextMenuService>;
}
