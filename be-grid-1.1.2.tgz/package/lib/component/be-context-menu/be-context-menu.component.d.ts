import { EventEmitter } from '@angular/core';
import { ContextMenuService } from "./context-menu.service";
import * as i0 from "@angular/core";
export declare class BeContextMenuComponent {
    contextMenu: ContextMenuService;
    x: number;
    y: number;
    toggleExport: boolean;
    excelExport: EventEmitter<any>;
    csvExport: EventEmitter<any>;
    constructor(contextMenu: ContextMenuService);
    excelExportDownload(): void;
    csvExportDownload(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BeContextMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BeContextMenuComponent, "be-context-menu", never, { "x": "x"; "y": "y"; "toggleExport": "toggleExport"; }, { "excelExport": "excelExport"; "csvExport": "csvExport"; }, never, never, false, never>;
}
