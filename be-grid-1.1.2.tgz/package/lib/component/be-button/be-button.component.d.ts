import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export declare class BeButtonComponent {
    label?: string;
    type?: string;
    color?: string;
    disabledButton?: boolean | false;
    hideButton?: boolean | false;
    rowData: any;
    btnClick: EventEmitter<any>;
    actionClick(action?: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BeButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BeButtonComponent, "be-button", never, { "label": "label"; "type": "type"; "color": "color"; "disabledButton": "disabledButton"; "hideButton": "hideButton"; "rowData": "rowData"; }, { "btnClick": "btnClick"; }, never, never, false, never>;
}
