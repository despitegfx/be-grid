import * as i0 from "@angular/core";
import * as i1 from "./component/be-grid/be-grid.component";
import * as i2 from "./component/be-button/be-button.component";
import * as i3 from "./component/be-context-menu/be-context-menu.component";
import * as i4 from "@angular/common";
import * as i5 from "@angular/material/slide-toggle";
import * as i6 from "@angular/material/table";
import * as i7 from "@angular/material/checkbox";
import * as i8 from "@angular/material/input";
import * as i9 from "@angular/material/form-field";
import * as i10 from "@angular/material/icon";
import * as i11 from "@angular/material/sort";
import * as i12 from "@angular/material/paginator";
import * as i13 from "@angular/cdk/drag-drop";
import * as i14 from "mat-table-exporter";
import * as i15 from "@angular/material/select";
export declare class BeGridModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BeGridModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BeGridModule, [typeof i1.BeGridComponent, typeof i2.BeButtonComponent, typeof i3.BeContextMenuComponent], [typeof i4.CommonModule, typeof i5.MatSlideToggleModule, typeof i6.MatTableModule, typeof i7.MatCheckboxModule, typeof i8.MatInputModule, typeof i9.MatFormFieldModule, typeof i10.MatIconModule, typeof i11.MatSortModule, typeof i12.MatPaginatorModule, typeof i13.DragDropModule, typeof i14.MatTableExporterModule, typeof i15.MatSelectModule], [typeof i1.BeGridComponent, typeof i2.BeButtonComponent, typeof i3.BeContextMenuComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BeGridModule>;
}
